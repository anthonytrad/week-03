<?php
if( isset($_GET['post']) || isset($_post['post_ID']) ) {
	$post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'] ;
	$template_file = get_post_meta($post_id,'_wp_page_template',TRUE);
	
	if ($template_file == 'homepage.php') {
		// Disable Editor
		function explora_remove_editor() {
			remove_post_type_support('page', 'editor');	
		}
		add_action( 'admin_init', 'explora_remove_editor' );
	}	
}

if( class_exists( 'Explora_Metaboxes_Metabox' ) ) {	
	
	
	new Explora_Metaboxes_Media_Slider( 
		'homepage_slider', array(
			'title' => esc_html__('Homepage Slider', 'thewall'),
			'post_types' => array( 'page' ),
			'templates' => array( 'homepage.php' ),
			'context' => 'normal',
			'priority' => 'high'
		)
	);
	
	
	new Explora_Metaboxes_Wall( 
		'homepage_wall', array(
			'title' => esc_html__('Homepage Wall', 'thewall'),
			'post_types' => array( 'page' ),
			'templates' => array( 'homepage.php' ),
			'context' => 'normal',
			'priority' => 'high'
		)
	);
	
}