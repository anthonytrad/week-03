<?php
  if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
    die (esc_html__('Please do not load this page directly. Thanks!', 'thewall'));

  if ( post_password_required() ) { ?>
    <p class="nocomments"><?php esc_html_e('This post is password protected. Enter the password to view the comments.', 'thewall') ?></p>
  <?php
    return;
  }

/*-----------------------------------------------------------------------------------*/
/*  Display the comments + Pings
/*-----------------------------------------------------------------------------------*/
if( comments_open() ) { 
?>
<section id="comments" class="comments <?php if(!have_comments()){ echo "no-comments"; } ?>">
    <div class="comentlist-wrapper">
        <ol class="commentlist page-inner-content">
<?php
    /*
     * If the current post is protected by a password and
     * the visitor has not yet entered the password we will
     * return early without loading the comments.
     */
    if ( post_password_required() )
        return;

    if ( have_comments() ) : ?>
        <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :  ?>
        <nav role="navigation" id="comment-nav-above" class="site-navigation comment-navigation">
            <h1 class="assistive-text"><?php esc_html_e( 'Comment navigation', 'thewall' ); ?></h1>
            <div class="nav-previous"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'thewall' ) ); ?></div>
            <div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'thewall' ) ); ?></div>
        </nav><!-- #comment-nav-before .site-navigation .comment-navigation -->
        <?php endif; // check for comment navigation ?>
 
          <?php wp_list_comments( array( 'callback' => 'thewall_shape_comment' ) ); ?>
        
        <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
        <nav role="navigation" id="comment-nav-below" class="site-navigation comment-navigation">
            <h1 class="assistive-text"><?php esc_html_e( 'Comment navigation', 'thewall' ); ?></h1>
            <div class="nav-previous"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'thewall' ) ); ?></div>
            <div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'thewall' ) ); ?></div>
        </nav><!-- #comment-nav-below .site-navigation .comment-navigation -->
        <?php endif; // check for comment navigation ?>
    <?php endif; // have_comments() ?>

<?php
/*-----------------------------------------------------------------------------------*/
/*  Comment Form
/*-----------------------------------------------------------------------------------*/
?>
  <div class="page-inner-content">
    <h2><?php esc_html_e('Leave A Comment', 'thewall') ?></h2>
    <div class="respond">
  
    <?php
    $commenter = wp_get_current_commenter();
    $req = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true'" : '' );
    $fields = array(
      'comment_field' => '<p class="form-comment"><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>',
      'must_log_in' => '<p class="must-log-in">' .  sprintf( wp_kses(__( 'You must be <a href="%s">logged in</a> to post a comment.', 'thewall' ), wp_kses_allowed_html( 'post' )), wp_login_url( apply_filters( 'the_permalink', get_permalink( ) ) ) ) . '</p>',
      'logged_in_as' => '<p class="logged-in-as">' . sprintf( wp_kses(__( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out &raquo;</a>', 'thewall' ), wp_kses_allowed_html( 'post' )), admin_url( 'profile.php' ), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) ) ) . '</p>',
      'comment_notes_before' => '',
      'comment_notes_after' => '',
      'title_reply' => '',
      'title_reply_to' => esc_html__('Leave a Reply to %s', 'thewall'),
      'cancel_reply_link' => esc_html__('x', 'thewall'),
      'label_submit' => esc_html__('SUBMIT COMMENT', 'thewall'),
      'fields' => apply_filters( 'comment_form_default_fields', array(
      'author' => '<p class="form-author field"><input required placeholder="'.esc_html__('NAME', 'thewall').'" id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" /></p>',
      'email' => '<p class="form-email field"><input required placeholder="'.esc_html__('EMAIL', 'thewall').'" id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" /></p>',
      'website' => '<p class="form-url field"><input placeholder="'.esc_html__('WEBSITE', 'thewall').'" id="url" name="url" type="text" value="' . esc_attr(  $commenter['comment_author_url'] ) . '" size="30" /></p>'
      ) )
    );
  
        comment_form($fields); ?>
    </div>
  </div>
    </ol><!-- .commentlist -->
  </div>
</section>
<?php } ?>