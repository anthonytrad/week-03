(function ($) {
    $(window).load(function(){
        
        ExploraCustomizer = {
            initControls: function(){
                ExploraCustomizer.controls.RadioImage.init();
                ExploraCustomizer.controls.Checkboxes.init();
            },
            controls: {
                RadioImage: {
                    init: function() {
                        // Use buttonset() for radio images.
                        $( '.customize-control-radio-image .buttonset' ).buttonset();

                        // Select default if no value is set
                        $(".customize-control-radio-image").each(function(){
                            var control = $(this);
                            if( control.find("input.stylish-radio-image:checked").length === 0 ) {
                                control.find('input.stylish-radio-image[data-default="1"]').attr('checked', 'checked');
                            }
                        });

                        // Handles setting the new value in the customizer.
                        $( '.customize-control-radio-image input:radio' ).change(
                            function() {
                                // Get the name of the setting.
                                var setting = $( this ).attr( 'data-customize-setting-link' );
                                // Get the value of the currently-checked radio input.
                                var image = $( this ).val();
                                // Set the new value.
                                wp.customize( setting, function( obj ) {
                                    obj.set( image );
                                } );
                            }
                        );
                    }
                },
                Checkboxes: {
                    init: function() {
                        var api = wp.customize;
 
                        // Loops through each instance of the category checkboxes control.
                        $('.explora-hidden-checkboxes').each(function(){

                            var id = jQuery(this).prop('id');
                            var categoryString = api.instance(id).get();
                            var categoryArray = categoryString.split(',');

                            // Checks/unchecks category checkboxes based on saved data.
                            $('#' + id).closest('.customize-control-checkboxes').find('.explora-customizer-checkbox').each(function() {

                                var elementID = $(this).prop('id').split('-');

                                if( $.inArray( elementID[1], categoryArray ) < 0 ) {
                                    $(this).prop('checked', false);
                                } else {
                                    $(this).prop('checked', true);
                                }

                            });     

                        });

                        // Sets listeners for checkboxes
                        $('.explora-customizer-checkbox').live('change', function(){

                            var id = $(this).closest('.customize-control-checkboxes').find('.explora-hidden-checkboxes').prop('id');
                            var elementID = $(this).prop('id').split('-');

                            if( $(this).prop('checked' ) == true ) {
                                addCategory(elementID[1], id);
                            } else {
                                removeCategory(elementID[1], id);
                            }

                        });

                        // Adds category ID to hidden input.
                        function addCategory( catID, controlID ) {

                            var categoryString = api.instance(controlID).get();
                            var categoryArray = categoryString.split(',');

                            if ( '' == categoryString ) {
                                var delimiter = '';
                            } else {
                                var delimiter = ',';
                            }

                            // Updates hidden field value.
                            if( $.inArray( catID, categoryArray ) < 0 ) {
                                api.instance(controlID).set( categoryString + delimiter + catID );
                            }
                        }

                        // Removes category ID from hidden input.
                        function removeCategory( catID, controlID ) {

                            var categoryString = api.instance(controlID).get();
                            var categoryArray = categoryString.split(',');
                            var catIndex = $.inArray( catID, categoryArray );

                            if( catIndex >= 0 ) {

                                // Removes element from array.
                                categoryArray.splice(catIndex, 1);

                                // Creates new category string based on remaining array elements.
                                var newCategoryString = '';
                                $.each( categoryArray, function() {
                                    if ( '' == newCategoryString ) {
                                        var delimiter = '';
                                    } else {
                                        var delimiter = ',';
                                    }
                                    newCategoryString = newCategoryString + delimiter + this;
                                });

                                // Updates hidden field value.
                                api.instance(controlID).set( newCategoryString );
                            }
                        }
                    }
                }
            }
        };
        
        ExploraCustomizer.initControls();
        
        
        
    });
}(jQuery));