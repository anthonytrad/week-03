<?php

add_action( 'customize_controls_enqueue_scripts', 'explora_enqueue_customizer_assets' );
function explora_enqueue_customizer_assets()
{
    wp_enqueue_script( 'jquery-ui-button' );
    wp_enqueue_script( 'explora-customizer-js', EXPLORA_CUSTOMIZER_URL . '/assets/explora_customizer.js', false, '1.0', true );
    wp_enqueue_style( 'explora-customizer-css', EXPLORA_CUSTOMIZER_URL . '/assets/explora_customizer.css', false, '1.0', 'all' );
}

require EXPLORA_CUSTOMIZER_DIR . '/fields/radio-image.php';
require EXPLORA_CUSTOMIZER_DIR . '/fields/textarea.php';
require EXPLORA_CUSTOMIZER_DIR . '/fields/rich-text.php';
require EXPLORA_CUSTOMIZER_DIR . '/fields/checkboxes.php';

?>