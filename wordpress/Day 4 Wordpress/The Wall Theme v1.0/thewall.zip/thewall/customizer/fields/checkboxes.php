<?php
class Explora_Customize_Control_Checkboxes extends WP_Customize_Control {
    public $type = 'checkboxes';
 
    public function render_content() { ?>
        <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
        <ul>
        <?php foreach ( $this->choices as $value => $label ) { ?>
            <li>
                <label>
                    <input type="checkbox" 
                           name="choice-<?php echo esc_attr( $value ); ?>" 
                           id="choice-<?php echo esc_attr( $value ); ?>" 
                           class="explora-customizer-checkbox" />
                    <?php echo esc_html($label); ?>
                </label>
            </li>
        <?php } ?>
        </ul>
        <input type="hidden" 
               id="<?php echo esc_attr($this->id); ?>" 
               class="explora-hidden-checkboxes" <?php echo esc_attr( $this->link() ); ?> 
               value="<?php echo sanitize_text_field( $this->value() ); ?>" />
<?php
    }
}
?>