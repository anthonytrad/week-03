<?php

/**
 * Radio image customize control.
 */

class Explora_Customize_Control_Radio_Image extends WP_Customize_Control {

    public $type = 'radio-image';

    public function render_content() {

      if ( empty( $this->choices ) )
        return;

      $name = '_customize-radio-' . $this->id;
      $default = $this->setting->default;

      ?>
      <label>
        <span class="customize-control-title">
            <?php echo esc_html( $this->label ); ?>
        </span>
        <?php foreach ( $this->choices as $value => $label ) : ?>
          <label>
            <input 
                type="radio" 
                value="<?php echo esc_attr( $value ); ?>" <?php $this->link(); checked( $this->value(), $value ); ?> 
                class="stylish-radio-image" 
                name="<?php echo esc_attr( $name ); ?>"
                data-default="<?php echo esc_attr($value == $default); ?>"
            />
            <span>
                <img 
                    src="<?php echo esc_url( $label ); ?>" 
                    alt="<?php echo esc_attr( $value ); ?>" 
                />
            </span>
          </label>
          <?php endforeach; ?>
      </label>
      <?php
    }
}
?>