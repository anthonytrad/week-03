<?php
function explora_customizer_add_panel ( $wp_customize, $id, $name, $priority ) {
    $prefix = "thewall_";
    
    $wp_customize->add_panel( $prefix . $id , array(
        'title'      => $name,
        'priority'   => $priority,
    ) );
    
    return $prefix . $id;

}

function explora_customizer_add_section ( $wp_customize, $id, $panel_id, $name, $priority ) {
    $prefix = "thewall_";
    
    $wp_customize->add_section( $prefix . $id , array(
        'title'      => $name,
        'priority'   => $priority,
        'panel'      => $panel_id
    ) );
    
    return $prefix . $id;

}

function explora_customizer_add_radio_option( $wp_customize, $section_id, $name, $id, $options, $default ){
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'esc_attr'
        )
    );
    $wp_customize->add_control($control_name, array(
        'label'      => $name,
        'section'    => $section_id,
        'settings'   => $control_name,
        'type'       => 'radio',
        'choices'    => $options
    ));
}

function explora_customizer_add_radio_image_option( $wp_customize, $section_id, $name, $id, $choices, $default ){
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'esc_attr' 
        )
    );
    $wp_customize->add_control(new Explora_Customize_Control_Radio_Image(
        $wp_customize,
        $control_name, 
        array(
            'label'      => $name,
            'section'    => $section_id,
            'choices'   => $choices
        )
    ));
}

function explora_customizer_add_color_option( $wp_customize, $section_id, $name, $id, $default, $opacity = true ){
    $prefix = "thewall_";
    
    $wp_customize->add_setting( 
            $prefix . $id,
            array(
                'default'           =>  $default,
                'sanitize_callback' =>  'sanitize_hex_color'
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                $prefix . $id,
                array(
                    'label'      => $name,
                    'section'    => $section_id,
                    'settings'   => $prefix . $id
                )
            )
        );
    
    if($opacity) {
        $wp_customize->add_setting( 
                $prefix . $id . '_opacity',
                array( 
                    'default'  =>  1,
                    'sanitize_callback' => 'esc_attr' 
                )
            );
            $wp_customize->add_control( $prefix . $id . '_opacity', array(
                'type'        => 'range',
                'section'     => $section_id,
                'label'       => $name . ' opacity',
                'input_attrs' => array(
                    'min'   => 0,
                    'max'   => 1,
                    'step'  => 0.1
                ),
            ) );
    }
    
}

function explora_customizer_add_range_option( $wp_customize, $section_id, $name, $id, $default = 50, $min = 0, $max = 100, $step = 1 ){
    $prefix = "thewall_";
    
    $wp_customize->add_setting( 
        $prefix . $id,
        array( 
            'default' => $default,
            'sanitize_callback' => 'esc_attr' 
        )
    );
    $wp_customize->add_control( $prefix . $id, array(
        'type'        => 'range',
        'section'     => $section_id,
        'label'       => $name,
        'input_attrs' => array(
            'min'   => $min,
            'max'   => $max,
            'step'  => $step
        ),
    ) );
}

function explora_customizer_add_background_option( $wp_customize, $section_id, $name, $id, $default, $no_image ){
    $prefix = "thewall_";
    
    $color_field_id = $prefix . $id . "_color";
    $image_field_id = $prefix . $id . "_image";
    $repeat_field_id = $prefix . $id . "_repeat";
    $attachment_field_id = $prefix . $id . "_attachment";
    $position_field_id = $prefix . $id . "_position";
    $size_field_id = $prefix . $id . "_size";
    
    // Background Color
    explora_customizer_add_color_option( $wp_customize, $section_id, $name . __(' Color', 'thewall'), $id . '_color', '', true );
    
    if( !$no_image ) {

        // Background Image
        $wp_customize->add_setting( $image_field_id, array(
                'default'        => '',
                'sanitize_callback' => 'esc_url_raw'
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $image_field_id, array(
                'label'   => $name . esc_html__(' Image', 'thewall'),
                'section' => $section_id,
                'settings'   => $image_field_id
            ) ) );

        // Background Image tile
        $wp_customize->add_setting( $repeat_field_id, array(
                'default'        => "0",
                'sanitize_callback' => 'esc_attr'
            ) );
            $wp_customize->add_control( $repeat_field_id, array(
                'label'   => $name . esc_html__(' Repeat', 'thewall'),
                'section' => $section_id,
                'type'    => 'radio',
                'choices' => array(esc_html__("No Repeat", "thewall"), esc_html__("Tile", "thewall"), esc_html__("Tile Horizontally", "thewall"), esc_html__("Tile Vertically", "thewall"))
            ) );

        // Background Attachment
        $wp_customize->add_setting( $attachment_field_id, array(
                'default'        => "0",
                'sanitize_callback' => 'esc_attr'
            ) );
            $wp_customize->add_control( $attachment_field_id, array(
                'label'   => $name . esc_html__(' Attachment', 'thewall'),
                'section' => $section_id,
                'type'    => 'radio',
                'choices' => array( esc_html__("Scroll", "thewall"), esc_html__("Fixed", "thewall") )
            ) );

        // Background Attachment
        $wp_customize->add_setting( $position_field_id, array(
                'default'        => "7",
                'sanitize_callback' => 'esc_attr'
            ) );
            $wp_customize->add_control( $position_field_id, array(
                'label'   => $name . esc_html__(' Position (horizontal and vertical)', 'thewall'),
                'section' => $section_id,
                'type'    => 'radio',
                'choices' => array(esc_html__("Left Top", "thewall"), esc_html__("Left Center", "thewall"), esc_html__("Left Bottom", "thewall"), esc_html__("Right Top", "thewall"), esc_html__("Right Center", "thewall"), esc_html__("Right Bottom", "thewall"), esc_html__("Center Top", "thewall"), esc_html__("Center Center", "thewall"), esc_html__("Center Bottom", "thewall"))
            ) );

        // Background Size
        $wp_customize->add_setting( $size_field_id, array(
                'default'        => "0",
                'sanitize_callback' => 'esc_attr'
            ) );
            $wp_customize->add_control( $size_field_id, array(
                'label'   => $name . ' Size',
                'section' => $section_id,
                'type'    => 'radio',
                'choices' => array("Auto", "Cover", "Contain")
            ) );
    }
    
    
}

function explora_customizer_add_logo_option( $wp_customize, $section_id, $name, $id, $default, $retina ){
    $prefix = "thewall_";
    
    $image_field_id = $prefix . $id;
    if( $retina ) { $retina_field_id = $prefix . $id . "_retina"; }
    
    // Background Image
    $wp_customize->add_setting( $image_field_id, array(
            'default'        => $default,
            'sanitize_callback' => 'esc_url_raw'
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $image_field_id, array(
            'label'   => $name . esc_html__(' Image', 'thewall'),
            'section' => $section_id,
            'settings'   => $image_field_id
        ) ) );
    
    if( $retina ) {
        // Background Image tile
        $wp_customize->add_setting( $retina_field_id, array(
                'default'        => "0",
                'sanitize_callback' => 'esc_attr'
            ) );
            $wp_customize->add_control( $retina_field_id, array(
                'label'   => $name . esc_html__(' Retina', 'thewall'),
                'section' => $section_id,
                'type'    => 'radio',
                'choices' => array(esc_html__("Retina Image", "thewall"), esc_html__("Normal Image", "thewall"))
            ) );
    }
    
}

function explora_customizer_add_text_option( $wp_customize, $section_id, $id, $name, $desc, $default ) {
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'sanitize_text_field' 
        )
    );
    $wp_customize->add_control( $control_name, 
        array(
            'type'       => 'text',
            'label'      => $name,
            'section'    => $section_id,
            'description'=> $desc
        )
    );
}

function explora_customizer_add_textarea_option( $wp_customize, $section_id, $id, $name, $desc, $default ) {
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'wp_kses_post' 
        )
    );
    $wp_customize->add_control(new Explora_Customize_Control_Textarea(
        $wp_customize,
        $control_name, 
        array(
            'label'      => $name,
            'description'=> $desc,
            'section'    => $section_id
        )
    ));
}

function explora_customizer_add_rich_text_option( $wp_customize, $section_id, $id, $name, $desc, $default ) {
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'sanitize_text_field' 
        )
    );
    $wp_customize->add_control(new Explora_Customize_Control_Checkboxes(
        $wp_customize,
        $control_name, 
        array(
            'label'      => $name,
            'description'=> $desc,
            'section'    => $section_id
        )
    ));
}

function explora_customizer_add_checkboxes_option( $wp_customize, $section_id, $id, $name, $options, $default ){
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $wp_customize->add_setting( 
        $control_name,
        array( 
            'default' =>  $default,
            'sanitize_callback' => 'esc_attr' 
        )
    );
    $wp_customize->add_control(new Explora_Customize_Control_Checkboxes(
        $wp_customize,
        $control_name, 
        array(
            'label'      => $name,
            'section'    => $section_id,
            'choices'   => $options
        )
    ));
}

function explora_customizer_add_posts_checkboxes_option( $wp_customize, $section_id, $id, $name ){
    $prefix = "thewall_";
    $control_name = $prefix . $id;
    
    $options = array();
    $posts_array = get_posts(array(
        'posts_per_page'   => -1
    ));
    foreach( $posts_array as $post ) {
        $options[$post->ID] = strip_tags($post->post_title);
    }
    
    explora_customizer_add_checkboxes_option( $wp_customize, $section_id, $id, $name, $options, "" );
    
}


// OUTPUT

function explora_get_background_option($option_id){
    $background_color = get_theme_mod($option_id . "_color" );
    $background_image = get_theme_mod( $option_id . "_image" );
    $background_repeat = get_theme_mod( $option_id . "_repeat" );
    $background_attachment = get_theme_mod( $option_id . "_attachment" );
    $background_position = get_theme_mod( $option_id . "_position" );
    $background_size = get_theme_mod( $option_id . "_size" );
    $background_opacity = get_theme_mod( $option_id . "_color_opacity" );
    
    $background_color = hex2rgba($background_color, $background_opacity);
    
    
    if($background_repeat == "0") $background_repeat = "no-repeat";
    if($background_repeat == "1") $background_repeat = "repeat";
    if($background_repeat == "2") $background_repeat = "repeat-x";
    if($background_repeat == "3") $background_repeat = "repeat-y";
    
    if($background_attachment == "0") $background_attachment = "scroll";
    if($background_attachment == "1") $background_attachment = "fixed";
    
    if($background_size == "0") $background_size = "auto";
    if($background_size == "1") $background_size = "cover";
    if($background_size == "2") $background_size = "contain";
    
    if($background_position == "0") $background_position = "left top";
    if($background_position == "1") $background_position = "left center";
    if($background_position == "2") $background_position = "left bottom";
    if($background_position == "3") $background_position = "right top";
    if($background_position == "4") $background_position = "right center";
    if($background_position == "5") $background_position = "right bottom";
    if($background_position == "6") $background_position = "center top";
    if($background_position == "7") $background_position = "center center";
    if($background_position == "8") $background_position = "center bottom";
    
    return "background-image: url(" . $background_image . "); " .
        "background-color: " . $background_color . "; " .
        "background-repeat: " . $background_repeat . ";" . 
        "background-attachment: " . $background_attachment . ";" .
        "background-size: " . $background_size . ";" .
        "background-position: " . $background_position . ";";
}

function hex2rgba($color, $opacity = false) {
 
	$default = '';
 
	//Return default if no color provided
	if(empty($color))
          return $default; 
 
	//Sanitize $color if "#" is provided 
        if ($color[0] == '#' ) {
        	$color = substr( $color, 1 );
        }
 
        //Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
                return $default;
        }
 
        //Convert hexadec to rgb
        $rgb =  array_map('hexdec', $hex);
 
        //Check if opacity is set(rgba or rgb)
        if($opacity){
        	if(abs($opacity) > 1)
        		$opacity = 1.0;
        	$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
        } else {
        	$output = 'rgb('.implode(",",$rgb).')';
        }
 
        //Return rgb(a) color string
        return $output;
}
?>