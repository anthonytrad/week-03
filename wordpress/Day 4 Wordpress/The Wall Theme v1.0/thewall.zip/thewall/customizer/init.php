<?php

define('EXPLORA_CUSTOMIZER_URL', get_template_directory_uri() . '/customizer');
define('EXPLORA_CUSTOMIZER_DIR', get_template_directory() . '/customizer');


add_action( 'customize_register', 'thewall_fields_register' );
function thewall_fields_register(){
    
    require EXPLORA_CUSTOMIZER_DIR . '/fields.php';
    
}

require EXPLORA_CUSTOMIZER_DIR . '/helpers.php';
require EXPLORA_CUSTOMIZER_DIR . '/register.php';
require EXPLORA_CUSTOMIZER_DIR . '/output.php';
?>