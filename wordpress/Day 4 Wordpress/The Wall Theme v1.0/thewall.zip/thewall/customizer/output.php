<?php
function thewall_get_custom_styles(){
?>
<style type="text/css">
    
    <?php 
    /******************/
    /*    General     */
    /******************/
    
    $primary_color = get_theme_mod( 'thewall_primary_color', '#e9cf92' );
    $main_menu_background = get_theme_mod( 'thewall_main_menu_background', '#f5f5f5' );
    $buttons_hover = get_theme_mod( 'thewall_buttons_hover', '#dfc687' );
    ?>
    .post .post-pages a:before, .single-explora_galleries section.sidebar-bottom, #main-navigation #thewall-cart button#toggle-cart:after, #main-navigation #thewall-cart:hover span.total, a#cancel-comment-reply-link, .explora-gallery.slider .flex-control-nav li a.flex-active, .explora-fullscreen-gallery > .middle > .inner .image-wrapper .likes, .wall .wall-module div.description .inner ul.post-categories li, .wall .wall-module.explora-gallery.slider .flex-control-nav li a.flex-active, section.comments h2:before, section.contact h2:before, .explora-gallery.grid .ribbon-wrapper .ribbon { background: <?php echo esc_attr($primary_color); ?>; }
    
   
    
    .post .date:before, .post ul.post-categories li, .post .actions .read-more, .post .post-pages span, .woocommerce a.button.alt, .woocommerce button.button, .woocommerce button, .woocommerce input.button, .woocommerce input.button.alt, .single-product.woocommerce div.product form.cart button, #review_form #commentform input[type="submit"], .woocommerce-cart table.cart input[type="submit"], .woocommerce-cart .wc-proceed-to-checkout a.checkout-button, section.sidebar aside, section.sidebar .widget_search input[type="submit"], section.comments .comment-form input[type="submit"], section.contact input[type="submit"], .comment-reply-link, .comment-edit-link { background-color: <?php echo esc_attr($primary_color); ?>; }
    
    .post .actions .read-more:hover, .post ul.post-categories li:hover, section.sidebar .widget_search input[type="submit"]:hover, section.comments .comment-form input[type="submit"]:hover, section.contact input[type="submit"]:hover { background: <?php echo esc_attr($buttons_hover); ?>; }
    
    
    
    em, .handwriting, .headline, .woocommerce div.product p.price span, ul.page-numbers li:hover a, .woocommerce .woocommerce-info:before, #review_form #commentform p.comment-form-rating p.stars a:hover:after, #main-navigation .wrapper .inner .menu .current-menu-item > a, .media-slider nav ul li span.number, section.sidebar aside.meta li:before, .explora-gallery.grid li span.price, .explora-gallery.grid li a.add_to_cart_button, .explora-fullscreen-gallery > .middle > .inner .content .meta li:before, a.dot-irecommendthis:before, .social-networks li:hover:before, .social-networks-wrapper .social-networks li:hover:before { color: <?php echo esc_attr($primary_color); ?>; }
    
    #main-navigation button.toggle:hover, .explora-gallery.grid li a.add_to_cart_button, .explora-gallery.grid li a.add_to_cart_button, .social-networks li:hover { border-color: <?php echo esc_attr($primary_color); ?>; }
    
    .woocommerce .woocommerce-message, .woocommerce .woocommerce-info, body.post-type-archive-product.woocommerce .explora-gallery li.added .image-wrapper:before, .explora-fullscreen-gallery > .middle > .inner .content-wrapper .scroll p:after { border-top-color: <?php echo esc_attr($primary_color); ?>; }
    
    .social-networks-wrapper:hover button.toggle { border-color: <?php echo esc_attr($primary_color); ?>!important; }
    
    @media all and (min-width: 1024px) {
        #main-navigation { background: <?php echo esc_attr($main_menu_background); ?>; }
        #main-navigation .wrapper .inner .menu > li.menu-item > a:after { background: <?php echo esc_attr($primary_color); ?>; }
    }
    
    body.single-post { <?php echo esc_attr( explora_get_background_option( "thewall_page_background_single_post" ) ); ?>; }
    
    body.single-explora_galleries { <?php echo esc_attr( explora_get_background_option( "thewall_page_background_album" ) ); ?>; }
    
    <?php 
    $pages = get_pages();
    foreach ( $pages as $page ) {
        ?>
        body.page-id-<?php echo esc_attr( $page->ID ); ?> { <?php echo esc_attr( explora_get_background_option( "thewall_page_background_" . $page->ID ) ); ?>; }
    <?php
    }
    
    echo esc_attr( get_theme_mod( 'thewall_custom_code_css', "" ) );
    ?>
</style>
<?php
}
?>