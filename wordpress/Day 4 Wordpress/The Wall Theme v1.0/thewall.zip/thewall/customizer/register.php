<?php

function thewall_customize_register( $wp_customize ) {
    /********************/
    /*      General     */
    /********************/
    $general_panel = explora_customizer_add_panel( $wp_customize, "general_panel", "General" , 1 );

   
    $logos_section = explora_customizer_add_section( $wp_customize, "logos_section", $general_panel, esc_html__("Logos", 'thewall') , 1 );
    explora_customizer_add_logo_option ($wp_customize, $logos_section, esc_html__("Logo", 'thewall'), "site_logo", get_template_directory_uri() . '/assets/images/default/logo.png', true);
    explora_customizer_add_logo_option ($wp_customize, $logos_section, esc_html__("Mobile Logo", 'thewall'), "site_logo_mobile", "", true);
    
    $sidebars_section = explora_customizer_add_section( $wp_customize, "sidebars_section", $general_panel, esc_html__("Sidebars Visibility", 'thewall') , 1 );
    
    $templates_options = array(
        "pages" => esc_html__("Custom Pages", 'thewall'),
        "albums" => esc_html__("Album Pages", 'thewall'),
        "blog" => esc_html__("Blog - Archive", 'thewall'),
        "posts" => esc_html__("Blog - Single Post", 'thewall'),
        "shop" => esc_html__("Shop", 'thewall')
    );
    explora_customizer_add_checkboxes_option ( $wp_customize, $sidebars_section, "sidebars_visibility", esc_html__("Sidebar visible on:", 'thewall'), $templates_options, "" );
    
    $colors_section = explora_customizer_add_section( $wp_customize, "colors_section", $general_panel, esc_html__("Colors", 'thewall') , 1 );
    
    explora_customizer_add_color_option( $wp_customize, $colors_section, esc_html__("Theme primary color", 'thewall'), "primary_color", "#e9cf92", $opacity = false );
    explora_customizer_add_color_option( $wp_customize, $colors_section, esc_html__("Main Menu background color", 'thewall'), "main_menu_background", "#f5f5f5", $opacity = true );
    explora_customizer_add_color_option( $wp_customize, $colors_section, esc_html__("Buttons hover color", 'thewall'), "buttons_hover", "#dfc687", $opacity = false );
    
    $footer_section = explora_customizer_add_section( $wp_customize, "footer_section", $general_panel, esc_html__("Footer", 'thewall') , 1 );
    
    explora_customizer_add_text_option( $wp_customize, $footer_section, "footer_text", esc_html__("Footer Text", 'thewall'), "",  wp_kses(__('&copy; COPYRIGHT 2015 <em>EXPLORA THEMES</em>. POWERED BY <a href="http://wordpress.org/">WORDPRESS</a>.', 'thewall'), wp_kses_allowed_html( 'post' )));
    
    /********************/
    /* Page Backgrounds */
    /********************/
    $backgrounds_panel = explora_customizer_add_panel( $wp_customize, "backgrounds_panel", esc_html__("Page Backgrounds", 'thewall') , 1 );
    
    $pages = get_pages();
    foreach ( $pages as $page ) {
        $template_file = get_post_meta($page->ID, '_wp_page_template', true);
        if( $template_file != 'homepage.php' ) {
            $section = explora_customizer_add_section( $wp_customize, "backgrounds_section_" . $page->ID, $backgrounds_panel, $page->post_title , 1 );
            explora_customizer_add_background_option( $wp_customize, $section, "", "page_background_" . $page->ID, "", false );   
        }
        
        $section = explora_customizer_add_section( $wp_customize, "backgrounds_section_single_post", $backgrounds_panel, esc_html__("Single Post pages", 'thewall') , 1 );
        explora_customizer_add_background_option( $wp_customize, $section, "", "page_background_single_post", "", false );
        
        $section = explora_customizer_add_section( $wp_customize, "backgrounds_section_album", $backgrounds_panel, esc_html__("Album pages", 'thewall') , 1 );
        explora_customizer_add_background_option( $wp_customize, $section, "", "page_background_album", "", false );
        
    }

    /*********************/
    /* Social & Sharing  */
    /*********************/
    
    $social_panel = explora_customizer_add_panel( $wp_customize, "social_panel", esc_html__("Social & Sharing", 'thewall') , 1 );
    
    /* Social Links */
    $social_links_section = explora_customizer_add_section( $wp_customize, "social_networks_links_section", $social_panel, esc_html__("Social networks links", 'thewall'), 1 );
    explora_customizer_add_textarea_option (
        $wp_customize, 
        $social_links_section, 
        "social_links", 
        esc_html__("Social Networks links (one per line)", 'thewall'),
        esc_html__("Choose the social networks that you want to include on your main menu.", 'thewall') . "<br><br>" . 
        esc_html__("The supported networks are: ", 'thewall') . "<br><br>
        <ul>
            <li>Facebook</li><li>Twitter</li><li>Behance</li><li>DeviantArt</li><li>Instagram</li>
            <li>Picasa</li><li>Vimeo</li><li>LinkedIn</li><li>Blogger</li><li>Dribble</li>
            <li>YouTube</li><li>Tumblr</li><li>Path</li><li>500px</li><li>Digg</li><li>Dropbox</li>
            <li>StumbleUpon</li><li>RSS Feeds</li><li>Skype</li><li>GrooveShark</li><li>DailyBooth</li>
            <li>Flickr</li><li>Last</li><li>Technorati</li><li>Rdio</li><li>Bebo</li><li>MySpace</li>
            <li>Gowalla</li><li>GitHub</li><li>Delicious</li><li>Viddler</li><li>Qik</li><li>Zerply</li>
            <li>Yahoo</li><li>WordPress</li><li>Mixx</li><li>Reddit</li><li>Forrst</li><li>TreeHouse</li>
            <li>Squidoo</li><li>Spotify</li><li>Hi5</li><li>Bing</li><li>Drive</li><li>Joomla</li>
            <li>Yelp</li><li>Google</li>
        </ul>",
        ""
    );
    
    /* Post Sharing buttons */
    $social_share_section = explora_customizer_add_section( $wp_customize, "social_share_section", $social_panel, esc_html__("Posts sharing buttons", 'thewall') , 1 );
    explora_customizer_add_checkboxes_option (
        $wp_customize,
        $social_share_section,
        "social_share_buttons",
        "",
        array(
            "facebook" => "Facebook",
            "twitter" => "Twitter",
            "googleplus" => "Google Plus",
            "tumblr" => "Tumblr",
            "pinterest" => "Pinterest",
            "linkedin" => "LinkedIn"
        ),
        ""
    );
    
    /********************/
    /*      Shop     */
    /********************/
    $shop_panel = explora_customizer_add_panel( $wp_customize, "shop_panel", esc_html__("Shop", 'thewall') , 1 );
    
    $shop_section = explora_customizer_add_section( $wp_customize, "shop_archive_section", $shop_panel, esc_html__("Shop - List of products", 'thewall') , 1 );
    explora_customizer_add_radio_option (
        $wp_customize,
        $shop_section,
        "Columns",
        "shop_list_columns",
        array( "1" => esc_html__("1 Column", 'thewall'), "2" => esc_html__("2 Columns", 'thewall'), "3" => esc_html__("3 Columns", 'thewall'), "4" => esc_html__("4 Columns", 'thewall'), "5" => esc_html__("5 Columns", 'thewall'), "6" => esc_html__("6 Columns", 'thewall') ),
        "4"
    );
    explora_customizer_add_radio_option (
        $wp_customize,
        $shop_section,
        esc_html__("Thumbnails quality (higher values can increase load times)", 'thewall'),
        "shop_thumbs_size",
        array( "medium" => esc_html__("Medium (~300px wide)", 'thewall'), "large" => esc_html__("Large (~600px wide)", 'thewall'), "full" => esc_html__("Full (original size)", 'thewall') ),
        "medium"
    );
    
    /*********************/
    /*    Custom Code    */
    /*********************/
    $custom_code_panel = explora_customizer_add_panel( $wp_customize, "custom_code_panel", esc_html__("Custom Code", 'thewall') , 1 );
    
    $custom_code_section = explora_customizer_add_section( $wp_customize, "custom_code_css_section", $custom_code_panel, esc_html__("Custom CSS", 'thewall') , 1 );
    explora_customizer_add_textarea_option ($wp_customize, $custom_code_section, "custom_code_css", "", "", "" );
    
    $custom_code_section = explora_customizer_add_section( $wp_customize, "custom_code_js_section", $custom_code_panel, esc_html__("Custom Scripts", 'thewall') , 1 );
    explora_customizer_add_textarea_option ($wp_customize, $custom_code_section, "custom_code_js", "", "", "" );
    
}
add_action( 'customize_register', 'thewall_customize_register' );
?>