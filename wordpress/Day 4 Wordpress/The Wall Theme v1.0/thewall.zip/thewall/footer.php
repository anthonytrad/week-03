<?php
$is_product = false;
if( function_exists('is_product') ) $is_product = is_product();
if( is_singular() && !is_attachment() && !$is_product && basename(get_page_template()) != "homepage.php" ) {
    get_template_part( 'partials/post/footer' );
} ?>
		<footer>
			<div class="page-inner-content">
			    <p><?php echo wp_kses( get_theme_mod( 'thewall_footer_text', '&copy; COPYRIGHT 2016 <em>EXPLORA THEMES</em>. POWERED BY <a href="http://wordpress.org/">WORDPRESS</a>.' ) , wp_kses_allowed_html( 'post' )); ?></p>
            </div>
		</footer>
	</main>
	<script type="text/javascript">
		<?php echo balanceTags( get_theme_mod( 'thewall_custom_code_js', "" ) ); ?>
	</script>
    <?php wp_footer(); ?>
</body>