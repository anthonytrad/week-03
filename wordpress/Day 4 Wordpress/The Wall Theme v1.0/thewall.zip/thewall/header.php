<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />	
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
		<?php wp_head(); ?>
	</head>
	
	<body <?php body_class( 'loading' ); ?>>
		<div class="body-loading">
			<div class="body-spinner">
				<div class="dot1"></div>
				<div class="dot2"></div>
			</div>
		</div>
		<main id="site-wrapper">
			<?php 
			get_template_part('partials/main_menu');
			$is_product = false;
			if( function_exists('is_product') ) $is_product = is_product();
			if( is_singular() && !is_attachment() && !$is_product && basename(get_page_template()) != "homepage.php" ) {
				get_template_part( 'partials/post/header' );
			} 
			?>