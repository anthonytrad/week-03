<?php
/*
Template Name: Homepage
*/
get_header();

if(have_posts()): while(have_posts()): the_post();

	if( function_exists('explora_wall_output') && function_exists('explora_metaboxes_media_slider_output') ){
		explora_metaboxes_media_slider_output( $post->ID, '_homepage_slider' );
		explora_wall_output( $post->ID, '_homepage_wall' );
	} else {
		echo wp_kses(__('<p>The Explora Metaboxes plugin seems to be missing. Please install and activate it.</p>', 'thewall'), wp_kses_allowed_html( 'post' ));
	}
	
endwhile; endif; 

get_footer(); ?>