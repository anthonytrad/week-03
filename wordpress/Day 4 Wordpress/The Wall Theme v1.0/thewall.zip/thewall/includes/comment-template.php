<?php
function thewall_shape_comment( $comment, $args, $depth ) {
  $GLOBALS['comment'] = $comment;
  switch ( $comment->comment_type ) :
      case 'pingback' :
      case 'trackback' :
  ?>
  <li class="post pingback">
      <p><?php _e( 'Pingback:', 'thewall' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( '(Edit)', 'thewall' ), ' ' ); ?></p>
  <?php
          break;
      default :
  ?>
  <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
      <article id="comment-<?php comment_ID(); ?>" class="comment">
      	<div class="comment-wrap page-inner-content">
      		<?php echo get_avatar( $comment, 55 ); ?>
					<div class="content">
						<p class="author-name">
              <strong><?php echo get_comment_author_link(); ?></strong>
              <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
								<time pubdate datetime="<?php comment_time( 'c' ); ?>"><?php printf( esc_html__( '%1$s at %2$s', 'thewall' ), get_comment_date(), get_comment_time() ); ?></time>
							</a>
            </p>
            <?php comment_text(); ?>
						<?php if ( $comment->comment_approved == '0' ) : ?><em><?php _e( 'Your comment is awaiting moderation.', 'thewall' ); ?></em><?php endif; ?>
						<footer>
	            <?php edit_comment_link( esc_html__( 'Edit', 'thewall' ), ' ' ); ?>
	            <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
						</footer>
					</div>
				</div>
      </article><!-- #comment-## -->

  <?php
          break;
  endswitch;
}
?>