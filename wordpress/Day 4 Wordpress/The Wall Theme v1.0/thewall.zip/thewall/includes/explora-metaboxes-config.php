<?php
	
/* This file defines which Post Types should the Explora Types plugin include. */
