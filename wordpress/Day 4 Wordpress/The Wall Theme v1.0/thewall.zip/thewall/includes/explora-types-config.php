<?php
	
/* This file defines which Post Types should the Explora Types plugin include. */
$explora_types_config = array(
	'explora_galleries' => array(
		'gallery_types' => array('grid', 'individual', 'carousel', 'video')
	)
);