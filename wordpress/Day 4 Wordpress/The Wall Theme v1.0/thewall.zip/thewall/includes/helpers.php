<?php
function thewall_getimagesize( $url ) {
    $width = 200;
    $height = 200;
    
    $file_headers = @get_headers($url);
    if($file_headers[0] == 'HTTP/1.1 404 Not Found') {
        return array( $width, $height );
    }
    
    $response = wp_remote_get( $url );
    if( is_array($response) ) {
        
        if( $response['headers']['content-type'] == 'image/png' && !function_exists('imagepng') ) {
            if( ini_get('allow_url_fopen') ) {
                return getimagesize( $url );   
            }
            return array( $width, $height );
        }
        
        $resource = imagecreatefromstring( $response['body'] );
        if( $resource ) {
            $width = imagesx($resource); 
            $height = imagesy($resource);    
        }
    }
    
    return array( $width, $height );
}

function thewall_get_logo( $resolution ) {
    $logo = "";
    $logo_retina = "";
    $logo_size = array(0, 0);
    
    if( $resolution == "mobile" ) {
        $logo = get_theme_mod('thewall_site_logo_mobile', "");
        $logo_retina = get_theme_mod('thewall_site_logo_mobile_retina', "0");
    }
    if( $resolution == "desktop" || $logo == "" ) {
        $logo = get_theme_mod('thewall_site_logo', get_template_directory_uri() . '/assets/images/default/logo.png');
        $logo_retina = get_theme_mod('thewall_site_logo_retina', "0");
    }
    
    $logo_size = thewall_getimagesize($logo);
    if( $logo_retina == "0" ) { 
        $logo_size = array( intval($logo_size[0]) / 2, intval($logo_size[1]) / 2); 
    }
    
    echo '<a href="' . site_url() . '"><img class="' . esc_attr( $resolution ) . '" src="' . $logo . '" style="width: ' . intval($logo_size[0]) . 'px; height: ' . intval($logo_size[1]) . 'px" alt="Site Logo" /></a>';
}

add_filter( 'the_password_form', 'thewall_password_form' );
function thewall_password_form() {
    global $post;
    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
    $o = 
    '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" class="post-password-form" method="post">
        <p><em class="handwriting">Wait!</em></p>
        <h5>PROTECTED AREA</h5>
        <p>Please enter your password to continue</p>
        <div>
            <input name="post_password" id="' . $label . '" type="password"size="20" />
            <input type="submit" name="Submit" class="button" value="' . esc_attr__( "Submit", "thewall" ) . '" />
        </div>
    </form>';
    return $o;
}

if( class_exists( 'Explora_Metaboxes_Metabox' ) ) {
    
    // Contact Page Metaboxes
    
    new Explora_Metaboxes_Metabox(
        'explora_contact_side_description_title', array(
            'title' => 'Side Description Title',
            'post_types' => array( 'page' ),
			'templates' => array( 'contact.php' ),
            'context' => 'side',
            'priority' => 'low'
        )
    );
    new Explora_Metaboxes_WYSIWYG_Editor(
        'explora_contact_side_description', array(
            'title' => 'Side Description',
            'post_types' => array( 'page' ),
			'templates' => array( 'contact.php' ),
            'context' => 'side',
            'priority' => 'low'
        )
    );
    new Explora_Metaboxes_Meta( 
        'explora_contact_side_meta', array(
            'title' => 'Side Contact Info',
            'post_types' => array( 'page' ),
			'templates' => array( 'contact.php' ),
            'context' => 'side',
            'priority' => 'low'
        )
    );
}

// Products FullWidth Option on Publish Box

add_action( 'post_submitbox_misc_actions', 'thewall_product_fullwidth_publish_option' );
add_action( 'save_post', 'thewall_save_product_fullwidth_publish_option' );
function thewall_product_fullwidth_publish_option() {
    global $post;
    if (get_post_type($post) == 'product') {
        echo '<div class="misc-pub-section misc-pub-section-last" style="border-top: 1px solid #eee;">';
        wp_nonce_field( '', 'product_fullwidth_publish_option_nonce' );
        $val = get_post_meta( $post->ID, '_product_fullwidth_publish_option', true ) ? get_post_meta( $post->ID, '_product_fullwidth_publish_option', true ) : '';
        echo '<input type="checkbox" name="product_fullwidth_publish_option" id="product_fullwidth_publish_option" value="fullwidth" '.checked($val,'fullwidth',false).' /> <label for="product_fullwidth_publish_option" class="select-it">Full Width Product</label><br />';
        echo '</div>';
    }
}
function thewall_save_product_fullwidth_publish_option($post_id) {

    if (!isset($_POST['post_type']) )
        return $post_id;

    if( isset( $_POST['product_fullwidth_publish_option_nonce'] ) ) {
        if ( !wp_verify_nonce( $_POST['product_fullwidth_publish_option_nonce'], '' ) )
            return $post_id;
    }

    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
        return $post_id;

    if ( 'product' == $_POST['post_type'] && !current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    
    if (isset($_POST['product_fullwidth_publish_option'])) {
        update_post_meta( $post_id, '_product_fullwidth_publish_option', $_POST['product_fullwidth_publish_option'], get_post_meta( $post_id, '_product_fullwidth_publish_option', true ) );
    } else {
        update_post_meta( $post_id, '_product_fullwidth_publish_option', false );
    }

}

add_theme_support( "title-tag" );
function thewall_wp_title( $title, $sep ) {
	global $paged, $page;
	if ( is_feed() ) {
		return $title;
	} // end if
	// Add the site name.
	$title .= get_bloginfo( 'name' );
	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title = "$title $sep $site_description";
	} // end if
	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 ) {
		$title = sprintf( __( 'Page %s', 'thewall' ), max( $paged, $page ) ) . " $sep $title";
	} // end if
	return $title;
} // end mayer_wp_title
add_filter( 'wp_title', 'thewall_wp_title', 10, 2 );