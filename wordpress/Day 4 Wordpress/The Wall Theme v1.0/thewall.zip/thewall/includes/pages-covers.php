<?php   
if( class_exists( 'Explora_Metaboxes_Metabox' ) ) {
    
    new Explora_Metaboxes_Gallery( 
        'thewall_post_gallery', array(
            'title' => 'Cover',
            'post_types' => array( 'post', 'page' ),
            'context' => 'normal',
            'priority' => 'high'
        )
    );
    
    new Explora_Metaboxes_Metabox( 
        'thewall_post_headline', array(
            'title' => 'Headline',
            'post_types' => array( 'post', 'page' ),
            'context' => 'side',
            'priority' => 'high'
        )
    );
}

/* 
 * Change Meta Box visibility according to Page Template
 */

add_action('admin_head', 'thewall_page_covers_script_enqueuer');

function thewall_page_covers_script_enqueuer() {
    global $current_screen;
    if( !isset($current_screen) ) return;
    if('page' != $current_screen->id) return;

    echo <<<HTML
        <script type="text/javascript">
        jQuery(document).ready( function($) {
            if($('#page_template').val() !== 'homepage.php') {
                $('#thewall_post_gallery').show();
            } else {
                $('#thewall_post_gallery').hide();
            }

            // Live adjustment of the meta box visibility
            $('#page_template').live('change', function(){
                if($(this).val() !== 'homepage.php') {
                    $('#thewall_post_gallery').show();
                } else {
                    $('#thewall_post_gallery').hide();
                }
            });                 
        });    
        </script>
HTML;
}