<?php

// Change number of columns for thumbnails on single product page
function thewall_xx_thumb_cols() {
    return 4;
}
add_filter ( 'woocommerce_product_thumbnails_columns', 'thewall_xx_thumb_cols' );

// Register WooCommerce sidebar
function woocommerce_sidebar() {
    if (is_woocommerce()) {
        dynamic_sidebar('woocommerce-product');
	}
}
add_action('woocommerce_before_shop_loop', 'woocommerce_sidebar', 40);


add_filter( 'woocommerce_output_related_products_args', 'thewall_related_products_args' );
function thewall_related_products_args( $args ) {
	$args['posts_per_page'] = 4; // 4 related products
	$args['columns'] = 4; // arranged in 2 columns
	return $args;
}

// Display all products on the archive page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return -1;' ), 20 );


// Change the thumbs on the archive page
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
if ( ! function_exists( 'woocommerce_template_loop_product_thumbnail' ) ) {
    function woocommerce_template_loop_product_thumbnail() {
        echo woocommerce_get_product_thumbnail();
    } 
}
if ( ! function_exists( 'woocommerce_get_product_thumbnail' ) ) {   
    function woocommerce_get_product_thumbnail( $size = 'shop_catalog', $placeholder_width = 0, $placeholder_height = 0  ) {
        global $post, $woocommerce;
        $is_fullwidth = get_post_meta( $post->ID, '_product_fullwidth_publish_option', true ) ? get_post_meta( $post->ID, '_product_fullwidth_publish_option', true ) : false;
        $image_size = $is_fullwidth ? "full" : "medium";
        
		$image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), get_theme_mod("thewall_shop_thumbs_size", $image_size) );
        $image_thumb_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'thumbnail' );	
		
        $image_id = get_post_thumbnail_id( $post->ID );
        $image_title = get_post_meta( $image_id, 'explora_galleries_photo_title', true );
        $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);      
        if( $image_alt == "" ) { $image_alt = $image_title; }
        if( $image_alt == "" ) { $image_alt = get_the_title($image_id); }
        if( $image_alt == "" ) { $image_alt = "Shop Item"; }
        
        if( $image_attributes &&  $image_thumb_attributes) {
			return '<div class="image-wrapper" style="padding-top: ' . esc_attr( intval($image_attributes[2]) / intval($image_attributes[1]) * 100 ) . '%">
						<img src="#" alt="' . esc_attr($image_alt) .'" data-url="' . esc_url( $image_attributes[0] ) . '" data-thumb-url="' . $image_thumb_attributes[0] . '" width="' . esc_attr( $image_attributes[1] ) . '" height="' . esc_attr( $image_attributes[2] ) . '" />
				  	</div>';
		}        
        return '';
    }
}

// Dynamic Cart Icon

// Ensure cart contents update when products are added to the cart via AJAX (place the following in functions.php)
add_filter('add_to_cart_fragments', 'thewall_woocommerce_header_add_to_cart_fragment');
function thewall_woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
    $items_qty = $woocommerce->cart->cart_contents_count;
    $cart_empty = ( $items_qty == 0 );
	ob_start();
	?>
    <div id="thewall-cart" class="<?php if($cart_empty){ echo "empty"; } ?>">
        <a href="<?php echo esc_attr( $woocommerce->cart->get_cart_url() ); ?>">
            <button id="toggle-cart" class="toggle icon icon-cart" data-items="<?php echo esc_attr( $items_qty ); ?>"></button>
            <?php if(!$cart_empty) { ?>
            <div id="thewall-cart-inner">
                <span>
                    <em><?php printf( _n( '%d ITEM', '%d ITEMS', $items_qty, 'thewall' ), $items_qty ); ?></em>&nbsp;
                    <?php _e("IN YOUR CART", "thewall") ?>
                    <span class="total"><?php echo wp_kses( $woocommerce->cart->get_cart_total(), wp_kses_allowed_html( 'post' ) ); ?></span>
                </span>
            </div>
            <?php } ?>
        </a>
    </div>
	<?php
	$fragments['#thewall-cart'] = ob_get_clean();
	return $fragments;
}