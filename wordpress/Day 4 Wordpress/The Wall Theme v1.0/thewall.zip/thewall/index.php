<?php
get_header();
if ( !post_password_required( $post ) ) {
	get_template_part('loops/blog-loop.php');
} else {
	echo get_the_password_form();
}
get_footer();
?>