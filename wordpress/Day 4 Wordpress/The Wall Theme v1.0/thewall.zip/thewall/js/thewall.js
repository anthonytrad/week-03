var TheWall, 
	TheWallBlog, 
	TheWallHome, 
	TheWallMenu, 
	TheWallSingle, 
	TheWallShop,
	TheWallAlbum;

;(function ($) {
    "use strict";
    TheWall = {
		settings: {
			clickEvent: 'click'
		},
		init: function(){
			var bodyClass = $('body').attr('class');
			
			// Configure the settings
			if(/iPhone|iPad|iPod/i.test(navigator.userAgent)){
				this.settings.clickEvent = 'touchstart';
			}
			
			// Init the interface
			this.Global.init();
			TheWallMenu.init();
			if( bodyClass.indexOf('homepage') > 0 ) {
				TheWallHome.init();	
			} else if( bodyClass.indexOf('woocommerce') > 0 ) {
				TheWallShop.init( bodyClass );
			} else if( bodyClass.indexOf('single-explora_galleries') > 0 ) {
				TheWallAlbum.init();	
			} else {
				TheWallBlog.init();	
			}
            if( bodyClass.indexOf('search-no-results') === -1 ) {
                TheWallSingle.init();    
            }
			
			setTimeout(function(){
				$('body').removeClass('loading');	
			}, 500);
			
		},
		Global: {
			init: function() {
				this.onInit.init();
				this.onResize.init();
			},
			onResize: {
				init: function(){
					
					theWallResize();
					$(window).resize( theWallResize );
					
					function theWallResize(){
						// Set #site-wrapper bottom padding to accomodate the footer
						$('#site-wrapper').css('padding-bottom', $('#site-wrapper > footer').outerHeight());
					}
				}
			},
			onInit: {
				init: function() {
					
					// Add "transparent" class to navigation if the page has a cover 
					if( $('#site-wrapper > .page').hasClass( 'has-cover' ) ) {
						$('#main-navigation').addClass('transparent');
					}
					
					// Check if the page has a sidebar
					if( $('section.sidebar').length > 0 ) {
						$('body').addClass('has-sidebar');
					} else {
						$('body').addClass('no-sidebar');
					}
					
				}
			}
		}
	}
	
	TheWallMenu = {
		init: function() {
			
			// Menu toggle button
			$('#toggle-main-nav').on( TheWall.settings.clickEvent , function(){
				$(this).toggleClass('open');
				$('#main-menu').toggleClass('open');
			});
			
			// Add toggle buttons
			$('#main-navigation .menu-item-has-children').each(function(){
				var menuItem = $(this),
					button = $('<button><i class="icon icon-arrow-right"></i></button>').appendTo(this);
				button.on( TheWall.settings.clickEvent , function(){
					menuItem.toggleClass('children-open');
					menuItem.find('> .sub-menu').toggleClass('open');
				});
			});
			
			// Add logo at the middle of the menu
			var centerItemIndex = Math.ceil($('#main-menu ul.menu > li').length / 2);
            
			$('#main-menu ul.menu > li:nth-child(' + centerItemIndex + ')').addClass('no-line').after(
				$('<li class="logo"></li>').html( $('.logo-desktop-placeholder').html() )
			);
			$('.logo-desktop-placeholder').remove();
			
		},
	};
	
	TheWallHome = {
		init: function(){
			this.Wall.init();
			this.Galleries.init();
		},
		Wall: {
			init: function(){ 
				$('.wall-module.explora-gallery.slider').each(function(){
					$(this).prev().addClass('before-slider');
					$(this).next().addClass('after-slider');
				});
			}
		},
		Galleries: {
			init: function(){
				
				// MAIN SLIDER
				$(".media-slider .explora-gallery.slider").ExploraGallery({
					type: "slider",
					itemSelector: ".gallery-item",
					slideshow: false,
				});
				
				var settings = {
					slideshow: true,
					interval: 5000
				};
				if( $(".media-slider").attr('data-slideshow') === "off" ) { settings.slideshow = false; }
				if( $(".media-slider").attr('data-interval') ) { settings.interval = parseInt( $(".media-slider").attr('data-interval'), 10 ); }
				
				$(".media-slider .nav-flexslider").flexslider({
					animation: "slide",
					slideshow: settings.slideshow,
					slideshowSpeed: settings.interval,
					itemWidth: 300,
					start: function( slider ) {
						$('.media-slider .nav-flexslider').resize();
						$('.media-slider .nav-flexslider li:nth-child(1)').addClass('flex-active-slide');
						$('.media-slider .nav-flexslider li:nth-child(2)').addClass('flex-after-active-slide');
					},
					before: function( slider ) {
						sliderSync( slider );
					},
					after: function( slider ) {
						sliderSync( slider );
					}
				});
				
				function sliderSync(slider){
					$('.media-slider .nav-flexslider li').removeClass('flex-active-slide flex-before-active-slide flex-after-active-slide');
						
					$('.media-slider .nav-flexslider li:nth-child(' + (slider.animatingTo)  + ')').addClass('flex-before-active-slide');
					$('.media-slider .nav-flexslider li:nth-child(' + (slider.animatingTo + 1)  + ')').addClass('flex-active-slide');
					$('.media-slider .nav-flexslider li:nth-child(' + (slider.animatingTo + 2)  + ')').addClass('flex-after-active-slide');
					
					$(".media-slider .explora-gallery.slider .inner").flexslider(slider.animatingTo);
				}
				
				$(".media-slider nav li").each(function(){
					var index = $(this).index() + 1;
					$(".media-slider .explora-gallery.slider li.gallery-item:nth-child(" + index + ") .image-wrapper").css("background-size", $(this).attr("data-display-mode"));
				});
				
				$(".media-slider nav li").on('click', function() {
					$(".media-slider .nav-flexslider").flexslider( $(this).index() );
				});
				
				
				// WALL GALLERIES
				
				$(".wall-module.explora-gallery.slider").ExploraGallery({
					type: "slider",
					itemSelector: ".gallery-item"
				});
				
				$(".explora-gallery.carousel").ExploraGallery({
					type: "carousel",
					itemSelector: ".gallery-item"
				});
				this.AlbumCarousels.init();
				
				$(".explora-gallery.grid").ExploraGallery({
					type: "grid",
					itemSelector: ".gallery-item"
				});
					
			},
			AlbumCarousels: {
				init: function() {
					$('.explora-gallery.carousel.album .flex-control-nav').wrap( $('<div class="thumbs-area"></div>') );
					$('.explora-gallery.carousel.album .description').each(function(){
						$(this).clone().prependTo( $(this).parent().find('.thumbs-area') );
					});
				}
			}
		}
	};
	
	TheWallAlbum = {
		init: function(){
			this.Gallery.init();
			this.Sidebar.init();
		},
		Gallery: {
			init: function(){
				$(".explora-gallery").ExploraGallery({
					type: "grid",
					parallax: $('#single-inner').hasClass('fullwidth')
				});
			}
		},
		Sidebar: {
			init: function(){
				var sidebarBottom = $('section.sidebar-bottom');
				if( sidebarBottom.length > 0 && sidebarBottom.find('aside.meta').length > 0 && sidebarBottom.find('aside.description').length > 0 ) {
					sidebarBottom.css('margin-bottom', sidebarBottom.find('aside.meta').outerHeight() - 40);
					$(window).resize(function(){
						sidebarBottom.css('margin-bottom', sidebarBottom.find('aside.meta').outerHeight() - 40);
					});
				}
			}
		}
	};
	
	TheWallBlog = {
		init: function() {
			this.Layout.init();
		},
		Layout: {
			init: function(){
				
				if( $('section.sidebar').length > 0 ) {
					$(window).resize(function(){
						fillHeight();
					});
					fillHeight();
					setTimeout( fillHeight, 1000 );
					setTimeout( fillHeight, 2000 );
					setTimeout( fillHeight, 5000 );
					setTimeout( fillHeight, 10000 );
				}
				
				function fillHeight() {
					var sidebarHeight = $('section.sidebar').outerHeight() + parseInt($('section.sidebar').css('margin-top'), 10) + parseInt($('section.sidebar').css('margin-bottom'), 10),
						blogHeight = $('.blog-wrapper').outerHeight();
                        
					if(  sidebarHeight > blogHeight ) {
						$('#desktop-fill').css('height', sidebarHeight);	
					}
				}
				
			}
		}
	};
	
	TheWallSingle = {
		init: function(){
			this.Layout.init();
			this.Gallery.init();
		},
		Layout: {
			init: function(){
				var offset = 0;
				
				if( $('section.sidebar').length > 0 ) {
					$(window).resize(function(){
						fillHeight();
					});
					fillHeight();
					setTimeout( fillHeight, 1000 );
					setTimeout( fillHeight, 2000 );
					setTimeout( fillHeight, 5000 );
					setTimeout( fillHeight, 10000 );
				}
				
				function fillHeight() {
					var contentHeight = $('.page-inner').outerHeight() +
										parseInt($('article.post').css('margin-top'), 10),
						sidebar = $('section.sidebar'),
						sidebarHeight = sidebar.outerHeight() + 
										parseInt( sidebar.css('top'), 10 ) + 
										parseInt( sidebar.css('margin-top'), 10 );
					
					if( $('.page').hasClass('has-cover') ) { contentHeight += $('.page > header').outerHeight(); }
						
					offset = sidebarHeight - contentHeight;
					
					if( offset > 0 ) {
						$('#desktop-fill').css('height', offset + 25);
					} else {
						$('#desktop-fill').css('height', 0);
					}
					
				}
			}
		},
		Gallery: {
			init: function(){
				$('header.post-cover .gallery').flexslider({
					smoothHeight: true
				});
			}
		}
	};
	
	TheWallShop = {
		init: function(bodyClass){
			if( bodyClass.indexOf('single-product') > 0 ) {
				this.Product.init();
			} else if( bodyClass.indexOf('post-type-archive-product') > 0 ) {
				this.Archive.init();
			}
		},
		Archive: {
			init: function(){
				this.Gallery.init();
			},
			Gallery: {
				init: function() {
					// Remove empty galleries
					$(".explora-gallery").each(function(){
						if( $(this).find('li.product').length === 0 ) $(this).remove();
					})
					
					// Create the gallery
					$(".explora-gallery").ExploraGallery({
						type: "grid",
						itemSelector: "li.product"
					});
					
					// Add class to added products
					$('.add_to_cart_button').on( TheWall.settings.clickEvent, function(){
						$(this).closest('li').addClass('added');
					});
				}
			}
		},
		Product: {
			init: function(){
				this.RelatedProducts.init();
				this.Meta.init();
				this.Reviews.init();
			},
			Meta: {
				init: function(){
					var html = $('div.product .posted_in').html().replace(/,\s/g, '<span class="bullet"></span>');
					$('div.product .posted_in').html( html );
				}
			},
			Reviews: {
				init: function(){
					
					$('#commentform input[type="text"], #commentform textarea').each(function(){
						var input = $(this),
							label = input.parent().find('label');
						input.attr('placeholder', label.text());
						label.hide();
					})
				}
			},
			RelatedProducts: {
				init: function() {
					$('div.related.products .explora-gallery').removeClass('explora-gallery');
					$('div.related.products img').each(function(){
						$(this).attr('src', $(this).attr('data-thumb-url'));
					});
				}
			}
		}
	};
	
})(jQuery);

TheWall.init();