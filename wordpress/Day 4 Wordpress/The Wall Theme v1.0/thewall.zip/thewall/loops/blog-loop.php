<div class="blog-wrapper">
<?php 
if ( have_posts() ) {
?>
    <section class="posts">
        <div class="inner">
            <?php 
            while ( have_posts() ) { 
                the_post(); ?>
            <article class="post">
                <?php get_template_part( 'partials/post/date' ); ?>
                <div class="inner">
                    <?php 
                    get_template_part( 'partials/post/title' );
                    the_category();
                    get_template_part( 'partials/post/meta' );
                    get_template_part( 'partials/post/header-list' ); 
                    ?>
                    <div class="content">
                        <?php the_excerpt(); ?>
                    </div>
                    <div class="actions">
                        <a href="<?php echo get_permalink(); ?>" class="button button-medium read-more"><?php esc_html_e('CONTINUE READING', "thewall"); ?></a>
                        <?php get_template_part('partials/share_buttons'); ?>
                    </div>
                </div>
            </article>
            <?php 
            } 
            ?>
            <nav>
            <?php 
            $args = array(
                'prev_next'          => False,
                'type'               => 'list'
            ); 
            echo paginate_links($args);
            ?>
            </nav>
        </div>
    </section>
    
<?php 
} else {
    get_template_part('partials/blog/no-results');
}

$sidebar_visibility = get_theme_mod("thewall_sidebars_visibility", "");
if( strpos($sidebar_visibility, "blog") !== false ) { get_sidebar(); }
?>
    <div id="desktop-fill"></div>
</div>