<?php
get_header();
if ( !post_password_required( $post ) ) {
    if ( have_posts() ) {
        while ( have_posts() ) { 
            the_post(); 
        ?>
    <div id="post-inner" class="page-inner clearfix">
        <div class="page-inner-content">
            <article class="post">
                <div class="inner">
                    <?php 
                    get_template_part( 'partials/post/title' );
                    the_category();
                    ?>
                    <div class="content">
					<?php the_content(); ?>
                    </div>
                </div> <!-- .inner -->
            </article> 
        </div> <!-- .page-inner-content -->
        <?php 
        comments_template(); 
        $sidebar_visibility = get_theme_mod("thewall_sidebars_visibility", "");
        if( strpos($sidebar_visibility, "pages") !== false ) { get_sidebar(); }
        ?>
    </div> <!-- .single-inner -->
    <div id="desktop-fill"></div>
        <?php
        }
    }
} else {
	echo get_the_password_form();
}
get_footer();
?>