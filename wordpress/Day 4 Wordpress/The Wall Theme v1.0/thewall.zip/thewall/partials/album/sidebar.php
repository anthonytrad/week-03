<?php
$layout = get_post_meta( $post->ID, '_explora_galleries_layout', true );
$description = get_post_meta( $post->ID, '_explora_galleries_description', true );
$meta = get_post_meta( $post->ID, '_explora_galleries_meta', true );
$meta = json_decode( $meta );
if( $meta || $description ) {
?>
<section class="album-sidebar sidebar<?php if( $layout == "fullwidth" ) echo "-bottom"; ?>">
    <div class="inner">
        <?php if( $description ){ ?>
        <aside class="description">
            <h5 class="widget-title">DESCRIPTION</h5>
            <?php echo wpautop( $description ); ?>
        </aside>
        <?php } ?>
        <?php
        if( $meta ) { ?>
        <aside class="meta">
            <ul>
        <?php foreach($meta as $item){ ?><li class="<?php echo esc_attr( $item->icon ); ?>"><?php echo esc_attr( $item->text ); ?></li><?php } ?>
            </ul>
        </aside>
        <?php } ?>
    </div>
</section>
<?php } ?>