<section id="noresults" class="posts">
    <p><?php esc_html_e("Search results for:", "thewall"); ?> <strong><?php echo esc_attr(get_search_query()); ?></strong></p>
    <h4><?php esc_html_e("No posts were found.", "thewall"); ?></h4>
    <p><?php esc_html_e("Please try searching for something else.", "thewall"); ?></p>
</section>
