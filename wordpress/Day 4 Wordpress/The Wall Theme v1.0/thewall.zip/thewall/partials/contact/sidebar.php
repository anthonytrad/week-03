<?php
$description_title = get_post_meta( $post->ID, '_explora_contact_side_description_title', true );
$description = get_post_meta( $post->ID, '_explora_contact_side_description', true );
$meta = get_post_meta( $post->ID, '_explora_contact_side_meta', true );
$meta = json_decode( $meta );
if( $description_title || $meta || $description ) {
?>
<section class="album-sidebar sidebar">
    <div class="inner">
        <?php if( $description ){ ?>
        <aside class="description">
            <h5 class="widget-title"><?php echo esc_attr($description_title); ?></h5>
            <?php echo wpautop( $description ); ?>
        </aside>
        <?php } ?>
        <?php
        if( $meta ) { ?>
        <aside class="meta">
            <ul>
        <?php foreach($meta as $item){ ?><li class="<?php echo esc_attr( $item->icon ); ?>"><?php echo esc_attr( $item->text ); ?></li><?php } ?>
            </ul>
        </aside>
        <?php } ?>
    </div>
</section>
<?php } ?>