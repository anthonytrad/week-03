<nav id="main-navigation" class="<?php if ( !class_exists( 'WooCommerce' ) ) { echo "no-cart"; }?>">
	<div class="top-bar mobile">
		<div class="logo">
			<?php thewall_get_logo( "mobile" ); ?>
		</div>
		<button id="toggle-main-nav" class="toggle-button">
			<span class="bar first"></span>
			<span class="bar middle"></span>
			<span class="bar last"></span>
		</button>
	</div>
	<div id="main-menu" class="page-inner-content" data-divide="auto">
		<div class="wrapper">
			<div class="inner">
				<?php wp_nav_menu(); ?>
			</div>
		</div>
		<?php get_template_part( 'partials/social-links' ); ?> 
	</div>
	<?php if ( class_exists( 'WooCommerce' ) ) { ?>
	<div id="thewall-cart">
		<button id="toggle-cart" class="toggle icon icon-cart"></button>
	</div>
	<?php } ?>
</nav>
<div class="logo-desktop-placeholder">
<?php thewall_get_logo( "desktop" ); ?>
</div>