<?php
$featured_image = wp_get_attachment_url( get_post_thumbnail_id() );
$gallery = get_post_meta( get_the_ID(), '_thewall_post_gallery', true );

if( !$featured_image ) {
	if( $gallery && strlen($gallery) > 0 ) {
		$gallery = explode(",", $gallery);
		$first = $gallery[0];
		$featured_image = wp_get_attachment_image_src( $first, "full" );
		$featured_image = $featured_image[0];
	}
}
if( $featured_image ) {
?>
<div class="featured-image" style="background-image: url(<?php echo esc_url($featured_image); ?>);">
	<img src="<?php echo esc_url($featured_image); ?>" alt="Featured Image">
</div>
<?php } ?>