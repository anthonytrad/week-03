<?php
$featured_image = wp_get_attachment_url( get_post_thumbnail_id() );
$gallery = get_post_meta( get_the_ID(), '_thewall_post_gallery', true );
if( get_post_type() == 'explora_galleries' ) {
	$gallery = get_post_meta( get_the_ID(), '_explora_galleries_cover', true );
}
$has_cover = "no-cover";
$featured = the_post_thumbnail();
if( $featured_image || ( $gallery && strlen($gallery) > 0 ) ) { $has_cover = "has-cover"; }
?>
<div class="page <?php echo esc_attr($has_cover); ?>">	
	<header class="post-cover">
	<?php if( $gallery && strlen($gallery) > 0 ) { ?>
		<div class="gallery">
			<ul class="slides">
	<?php
		$gallery = explode(",", $gallery);
		foreach($gallery as $key => $value){
			$attachment = get_post( $value );
			$image = wp_get_attachment_image_src( $value, "full" );
			$image = array( 'src' => $image[0] );
	?>
			<li style="background-image: url(<?php echo esc_url($image['src']); ?>)"></li>
	<?php } ?>
			</ul>
		</div>
	<?php
	} else if( $featured_image ) { ?>
		<div class="cover" style="background-image: url(<?php echo esc_html($featured_image); ?>)"></div>
	<?php 
	}
	?>
	</header>