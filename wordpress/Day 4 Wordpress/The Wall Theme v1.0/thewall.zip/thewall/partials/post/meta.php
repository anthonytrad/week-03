<ul class="post-meta">
	<li class="author"><?php the_author_posts_link(); ?></li>
	<li class="comments icon icon-comment">
		<a href="<?php comments_link(); ?>"><?php comments_number("0", "1", "%"); ?></a>
	</li>
	<?php if( function_exists('dot_irecommendthis') ) { ?>
	<li class="likes icon"> <?php dot_irecommendthis(); ?></li>
	<?php } ?>
</ul>