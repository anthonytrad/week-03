<?php 
$headline = get_post_meta( get_the_ID(), '_thewall_post_headline', true ); 
if( $headline ) {
?>
<span class="headline"><?php echo wp_kses( $headline, wp_kses_allowed_html( 'post' ) ); ?></span>
<?php	
}
?>
<h3 class="post-title">
<?php 
if( !is_single() ) { ?>
    <a href="<?php echo get_permalink(); ?>">
        <?php if(is_sticky()) { echo '<i class="icon icon-pin"></i>'; }
}
    the_title();
if( !is_single() ) { ?></a><?php } 
?>
</h3>