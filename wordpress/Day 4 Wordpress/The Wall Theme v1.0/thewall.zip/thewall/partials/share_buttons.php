<?php 
$social_buttons = get_theme_mod( 'thewall_social_share_buttons' );
if(strlen($social_buttons) > 0){
?>
<ul class="share">
	<?php if( strpos($social_buttons, "facebook") !== false ) { ?>
	<li><a class="icon-social icon-social-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url( get_permalink() ); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"></a></li>
	<?php } ?>
	<?php if( strpos($social_buttons, "googleplus") !== false ) { ?>
	<li><a class="icon-social icon-social-google" href="https://plus.google.com/share?url=<?php echo esc_url( get_permalink() ); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=500,width=400');return false;"></a></li>
	<?php } ?>
	<?php if( strpos($social_buttons, "linkedin") !== false ) { ?>
	<li><a class="icon-social icon-social-linkedin" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url( get_permalink() ); ?>&amp;title=&amp;summary=&amp;source=" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"></a></li>
	<?php } ?>
	<?php if( strpos($social_buttons, "pinterest") !== false ) { ?>
	<li><a class="icon-social icon-social-pinterest" href="https://pinterest.com/pin/create/button/?url=<?php echo esc_url( get_permalink() ); ?>&amp;media=<?php echo esc_url( $featured_image ); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"></a></li>
	<?php } ?>
	<?php if( strpos($social_buttons, "twitter") !== false ) { ?>
	<li><a class="icon-social icon-social-twitter-1" href="https://twitter.com/home?status=<?php echo esc_attr(__("Check out this article: ", "thewall") . get_the_title() . "%20-%20" . get_permalink() ); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"></a></li>
	<?php } ?>
	<?php if( strpos($social_buttons, "tumblr") !== false ) { ?>
	<li><a class="icon-social icon-social-tumblr" href="http://www.tumblr.com/share/link?url=<?php echo esc_url( get_permalink() ); ?>&amp;name=<?php echo esc_url( get_the_title() ); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=500,width=400');return false;"></a></li>
	<?php } ?>
</ul>
<?php } ?>