<?php
$list = '';
$networks = array(
    'facebook' => 'facebook',
    'twitter' => 'twitter',
    'behance' => 'behance',
    'deviantart' => 'deviantart',
    'instagram' => 'instagram',
    'picasa' => 'picasa',
    'pinterest' => 'pinterest',
    'vimeo' => 'vimeo',
    'linkedin' => 'linkedin',
    'blogger' => 'blogger',
    'dribble' => 'dribble',
    'youtube' => 'youtube',
    'tumblr' => 'tumblr',
    'path' => 'path',
    '500px' => '500px',
    'digg' => 'digg',
    'dropbox' => 'dropbox',
    'stumbleupon' => 'stumbleupon',
    'RSS' => 'rss',
    'skype' => 'skype',
    'grooveshark' => 'grooveshark',
    'dailybooth' => 'dailybooth',
    'flickr' => 'flickr',
    'last' => 'last',
    'technorati' => 'technorati',
    'rdio' => 'rdio',
    'bebo' => 'bebo',
    'myspace' => 'myspace-alt',
    'gowalla' => 'gowalla',
    'github' => 'github-alt',
    'delicious' => 'delicious',
    'viddler' => 'viddler',
    'qik' => 'qik',
    'zerply' => 'zerply',
    'yahoo' => 'yahoo',
    'wordpress' => 'wordpress',
    'mixx' => 'mixx-alt',
    'reddit' => 'reddit',
    'forrst' => 'forrst',
    'medium' => 'medium',
    'treehouse' => 'treehouse',
    'squidoo' => 'squidoo',
    'spotify' => 'spotify',
    'hi5' => 'hi5',
    'bing' => 'bing',
    'drive' => 'drive',
    'joomla' => 'joomla',
    'yelp' => 'yelp',
    'google' => 'google'
);

$raw = get_theme_mod("thewall_social_links", "");
$raw_array = explode("\n", $raw);

if(strlen($raw) > 0) {
    foreach ($raw_array as $key => $value){
        foreach($networks as $url => $class) {
            if( strpos($value, $url) !== false  ) {
                $list .= '<li class="icon-social icon-social-' . strtolower( esc_attr( $class ) ) . '"><a target="_blank" href="' . esc_attr( $value ) . '"></a></li>';         
            }
        }
    } 
    if ( $list ) { ?>
<div class="social-networks-wrapper">
    <button id="toggle-social-links" class="toggle icon icon-share"></button>
	<ul class="social-networks">
	<?php echo wp_kses( $list, wp_kses_allowed_html( 'post' ) ); ?>
	</ul>
</div>
<?php
    }
}
?>