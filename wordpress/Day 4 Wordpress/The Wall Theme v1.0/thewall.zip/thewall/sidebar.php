<?php if( is_active_sidebar('sidebar') ) { ?>
<section class="sidebar">
    <div class="inner">
        <?php dynamic_sidebar('sidebar'); ?>
    </div>
</section>
<?php } ?>