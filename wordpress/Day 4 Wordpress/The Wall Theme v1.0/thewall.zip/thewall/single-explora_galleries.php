<?php
get_header();
if ( !post_password_required( $post ) ) {
    if ( have_posts() ) {
        while ( have_posts() ) { 
            the_post(); 
            $layout = get_post_meta( $post->ID, '_explora_galleries_layout', true );
            if( !$layout ) $layout = "default";
        ?>
    <div id="single-inner" class="page-inner clearfix <?php echo esc_attr($layout); ?>">
        <div class="page-inner-content">
            <article class="post">
                <?php get_template_part( 'partials/post/date' ); ?>
                <div class="inner">
                    <?php  get_template_part( 'partials/post/title' ); ?>
                    <div class="content">
                    <?php 
                    $columns = get_post_meta( $post->ID, '_explora_galleries_columns', true );
                    if( $columns == "" ) { $columns = 3; }
                    echo wpautop(get_post_meta( $post->ID, '_explora_galleries_heading_text', true ));
                    if( function_exists('explora_gallery_output') ){
                        explora_gallery_output( $post, $columns );
                    } else {
                        echo wp_kses(__('<p>The Explora Types plugin seems to be missing. Please install and activate it.</p>', 'thewall'), wp_kses_allowed_html( 'post' ));
                    } ?>
                    </div>
                </div> <!-- .inner -->
                <?php if( $layout == "fullwidth" ) get_template_part( 'partials/album/sidebar' ); ?>
            </article>
        </div> <!-- .page-inner-content -->
        <?php if( $layout == "default" ) get_template_part( 'partials/album/sidebar' ); ?>
    </div> <!-- .single-inner -->
    <div id="desktop-fill"></div>
        <?php
        }
    } else {
        get_template_part('partials/blog/no-results.php');
    }
} else {
	echo get_the_password_form();
}
get_footer();
?>