<?php
get_header();
if ( !post_password_required( $post ) ) {
    if ( have_posts() ) {
        while ( have_posts() ) { 
            the_post(); 
        ?>
    <div id="single-inner" class="page-inner clearfix">
        <div class="page-inner-content">
            <article class="post">
                <?php get_template_part( 'partials/post/date' ); ?>
                <div class="inner">
                    <?php 
                    get_template_part( 'partials/post/title' );
                    the_category();
                    get_template_part( 'partials/post/meta' ); 
                    ?>
                    <div class="content">
                        <?php 
                        the_content();
                        wp_link_pages( array( 
                            'before' => '<p class="post-pages"><span>',
                            'after' => '</span></p>',
                            'separator' => '</span><span>',
                            'link_before'      => '<i>',
                            'link_after'       => '</i>',
                        ) ); 
                        ?>
                    </div>
                    <?php the_tags('<ul id="tags"><li>', '</li><li>', '</li></ul>'); ?>
                    <div class="actions">
                        <?php get_template_part('partials/share_buttons.php'); ?>
                    </div>
                </div> <!-- .inner -->
            </article> 
        </div> <!-- .page-inner-content -->
        <?php 
        comments_template(); 
        $sidebar_visibility = get_theme_mod("thewall_sidebars_visibility", "");
        if( strpos($sidebar_visibility, "posts") !== false ) { get_sidebar(); }
        ?>
    </div> <!-- .single-inner -->
    <div id="desktop-fill"></div>
        <?php
        }
    } else {
        get_template_part('partials/blog/no-results.php');
    }
} else {
	echo get_the_password_form();
}
get_footer();
?>