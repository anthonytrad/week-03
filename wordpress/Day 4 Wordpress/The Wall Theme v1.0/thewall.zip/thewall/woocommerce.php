<?php get_header(); ?>
<div class="page">
	<div id="post-inner" class="page-inner clearfix">
		<div class="page-inner-content">
			<article class="post">
			<?php woocommerce_content(); ?>
			</article>
		</div> <!-- .page-inner-content -->
	</div> <!-- .single-inner -->
	<div id="desktop-fill"></div>
</div>
<?php get_footer(); ?>