<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div class="explora-gallery grid" data-columns="<?php echo esc_attr(get_theme_mod("thewall_shop_list_columns", "4")); ?>">
	<div class="gallery-wrapper">
		<div class="inner">
			<ul>